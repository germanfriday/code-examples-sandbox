//
//  RootViewController.h
//  RSS Reader
//
//  Created by Ben on 17/08/2009.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

@class RSSXMLParser;

@interface RootViewController : UITableViewController {
	RSSXMLParser * rssParser;
}

@end
