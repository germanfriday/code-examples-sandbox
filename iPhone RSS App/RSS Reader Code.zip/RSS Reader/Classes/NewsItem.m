//
//  NewsItem.m
//  RSS Reader
//
//  Created by Ben on 17/08/2009.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "NewsItem.h"


@implementation NewsItem
@synthesize title, description, link;

@end
