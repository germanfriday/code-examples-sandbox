Fonts:

***********************************************
Nimbus Sans L regular
"nimbus.ttf" - An "arial"-look-alike font. If you want to use the real Arial font you should upload the arial-normal ttf file from your Windows system (fonts/arial.ttf).
***********************************************

From "http://www.math.utah.edu/~beebe/fonts/urw.html":
--------
URW (Unternehmensberatung Rubow Weber, from the founders' names), in Hamburg, Germany, produces font software (notably, the IKARUS font design system), fonts, and logos. They offer at least eleven font CD ROMs, some with 500 or more typefaces, and also sell font CD ROMs produced by other font vendors. 
A list of 4291 font names in several CD ROM distributions is available. 

URW also very kindly contributed freely-distributable Type 1 fonts to Aladdin Enterprises for use with the Ghostscript PostScript interpreter, thereby providing high-quality outline fonts for the fonts commonly available in PostScript printers. 

URW can be found on the World-Wide Web at http://www.urwpp.de/ and terrestrially at 

URW++ Design & Development GmbH
Poppenb�tteler Bogen 29A, D-22399 Hamburg
Germany
Tel: +49 (40) 60 60 50
Fax: +49 (40) 60 60 5 111 
--------



***********************************************
Bitstream Vera Sans
"vera.ttf" - A "verdana"-look-alike font. If you want to use the real Verdana font you should upload the verdana-normal ttf file from your Windows system (fonts/verdana.ttf).
***********************************************

More information:
http://www.bitstream.com/categories/products/fonts/vera/

--------
Bitstream Vera will be released for use under a special open license agreement, giving advanced font capabilities to all free and open source software developers and users.
--------
