<?php
define('TYPO3_MOD_PATH', 'sysext/impexp/app/');
$BACK_PATH='../../../';

$MCONF['name']='xMOD_tximpexp';	// xMOD_[modulename][optional: '_something']
?>
