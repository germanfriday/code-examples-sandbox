<?php
define('TYPO3_MOD_PATH', 'sysext/cms/layout/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'layout.gif';
$MLANG['default']['ll_ref']='LLL:EXT:cms/layout/locallang_mod.php';

$MCONF['script']='db_layout.php';
$MCONF['access']='user,group';
$MCONF['name']='web_layout';
?>