<?php
/***************************************************************
*  Copyright notice
*
*  (c) 1999-2005 Kasper Skaarhoj (kasperYYYY@typo3.com)
*  All rights reserved
*
*  This script is part of the TYPO3 project. The TYPO3 project is
*  free software; you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation; either version 2 of the License, or
*  (at your option) any later version.
*
*  The GNU General Public License can be found at
*  http://www.gnu.org/copyleft/gpl.html.
*  A copy is found in the textfile GPL.txt and important notices to the license
*  from the author is found in LICENSE.txt distributed with these scripts.
*
*
*  This script is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  This copyright notice MUST APPEAR in all copies of the script!
***************************************************************/
/**
 * Module: Web>Page
 *
 * This module lets you view a page in a more Content Management like style than the ordinary record-list
 *
 * $Id: db_layout.php,v 1.32.2.6 2006/03/22 02:10:45 mundaun Exp $
 * Revised for TYPO3 3.6 November/2003 by Kasper Skaarhoj
 * XHTML compliant
 *
 * @author	Kasper Skaarhoj <kasperYYYY@typo3.com>
 */
/**
 * [CLASS/FUNCTION INDEX of SCRIPT]
 *
 *
 *
 *  106: class ext_posMap extends t3lib_positionMap
 *  117:     function wrapRecordTitle($str,$row)
 *  130:     function wrapColumnHeader($str,$vv)
 *  144:     function onClickInsertRecord($row,$vv,$moveUid,$pid)
 *  160:     function wrapRecordHeader($str,$row)
 *
 *
 *  181: class SC_db_layout
 *  230:     function init()
 *  283:     function menuConfig()
 *  372:     function clearCache()
 *  387:     function main()
 *  489:     function renderQuickEdit()
 *  886:     function renderListContent()
 * 1165:     function printContent()
 *
 *              SECTION: Other functions
 * 1192:     function getNumberOfHiddenElements()
 * 1205:     function local_linkThisScript($params)
 * 1217:     function exec_languageQuery($id)
 *
 * TOTAL FUNCTIONS: 14
 * (This index is automatically created/updated by the extension "extdeveval")
 *
 */


unset($MCONF);
require('conf.php');
require($BACK_PATH.'init.php');
require($BACK_PATH.'template.php');
$LANG->includeLLFile('EXT:cms/layout/locallang.xml');
require_once(PATH_t3lib.'class.t3lib_pagetree.php');
require_once(PATH_t3lib.'class.t3lib_page.php');
require_once(PATH_t3lib.'class.t3lib_recordlist.php');
require_once(PATH_typo3.'class.db_list.inc');
require_once('class.tx_cms_layout.php');
require_once(PATH_t3lib.'class.t3lib_positionmap.php');
$BE_USER->modAccess($MCONF,1);

// Will open up records locked by current user. It's assumed that the locking should end if this script is hit.
t3lib_BEfunc::lockRecords();

// Exits if 'cms' extension is not loaded:
t3lib_extMgm::isLoaded('cms',1);











/**
 * Local extension of position map class
 *
 * @author	Kasper Skaarhoj <kasperYYYY@typo3.com>
 * @package TYPO3
 * @subpackage core
 */
class ext_posMap extends t3lib_positionMap {
	var $dontPrintPageInsertIcons = 1;
	var $l_insertNewRecordHere='newContentElement';

	/**
	 * Wrapping the title of the record.
	 *
	 * @param	string		The title value.
	 * @param	array		The record row.
	 * @return	string		Wrapped title string.
	 */
	function wrapRecordTitle($str,$row)	{
		$aOnClick = 'jumpToUrl(\''.$GLOBALS['SOBE']->local_linkThisScript(array('edit_record'=>'tt_content:'.$row['uid'])).'\');return false;';
		return '<a href="#" onclick="'.htmlspecialchars($aOnClick).'">'.$str.'</a>';
	}

	/**
	 * Wrapping the column header
	 *
	 * @param	string		Header value
	 * @param	string		Column info.
	 * @return	string
	 * @see printRecordMap()
	 */
	function wrapColumnHeader($str,$vv)	{
		$aOnClick = 'jumpToUrl(\''.$GLOBALS['SOBE']->local_linkThisScript(array('edit_record'=>'_EDIT_COL:'.$vv)).'\');return false;';
		return '<a href="#" onclick="'.htmlspecialchars($aOnClick).'">'.$str.'</a>';
	}

	/**
	 * Create on-click event value.
	 *
	 * @param	array		The record.
	 * @param	string		Column position value.
	 * @param	integer		Move uid
	 * @param	integer		PID value.
	 * @return	string
	 */
	function onClickInsertRecord($row,$vv,$moveUid,$pid) {
		if (is_array($row))	{
			$location=$GLOBALS['SOBE']->local_linkThisScript(array('edit_record'=>'tt_content:new/-'.$row['uid'].'/'.$row['colPos']));
		} else {
			$location=$GLOBALS['SOBE']->local_linkThisScript(array('edit_record'=>'tt_content:new/'.$pid.'/'.$vv));
		}
		return 'jumpToUrl(\''.$location.'\');return false;';
	}

	/**
	 * Wrapping the record header  (from getRecordHeader())
	 *
	 * @param	string		HTML content
	 * @param	array		Record array.
	 * @return	string		HTML content
	 */
	function wrapRecordHeader($str,$row)	{
		if ($row['uid']==$this->moveUid)	{
			return '<img'.t3lib_iconWorks::skinImg($GLOBALS['BACK_PATH'],'gfx/content_client.gif','width="7" height="10"').' alt="" />'.$str;
		} else return $str;
	}
}








/**
 * Script Class for Web > Layout module
 *
 * @author	Kasper Skaarhoj <kasperYYYY@typo3.com>
 * @package TYPO3
 * @subpackage core
 */
class SC_db_layout {

		// Internal, GPvars:
	var $id;					// Page Id for which to make the listing
	var $pointer;				// Pointer - for browsing list of records.
	var $imagemode;				// Thumbnails or not

	var $search_field;			// Search-fields
	var $search_levels;			// Search-levels
	var $showLimit;				// Show-limit
	var $returnUrl;				// Return URL

	var $clear_cache;			// Clear-cache flag - if set, clears page cache for current id.
	var $popView;				// PopView id - for opening a window with the page
	var $edit_record;			// QuickEdit: Variable, that tells quick edit what to show/edit etc. Format is [tablename]:[uid] with some exceptional values for both parameters (with special meanings).
	var $new_unique_uid;		// QuickEdit: If set, this variable tells quick edit that the last edited record had this value as UID and we should look up the new, real uid value in sys_log.

		// Internal, static:
	var $perms_clause;			// Page select perms clause
	var $modTSconfig;			// Module TSconfig
	var $pageinfo;				// Current ids page record
	var $doc;					// Document template object
	var $backPath;				// Back path of the module

	var $descrTable;			// "Pseudo" Description -table name
	var $colPosList;			// List of column-integers to edit. Is set from TSconfig, default is "1,0,2,3"
	var $EDIT_CONTENT;			// Flag: If content can be edited or not.
	var $CALC_PERMS;			// Users permissions integer for this page.
	var $current_sys_language;	// Currently selected language for editing content elements

	var $MCONF=array();			// Module configuration
	var $MOD_MENU=array();		// Menu configuration
	var $MOD_SETTINGS=array();	// Module settings (session variable)
	var $include_once=array();	// Array, where files to include is accumulated in the init() function

		// Internal, dynamic:
	var $content;				// Module output accumulation
	var $topFuncMenu;			// Function menu temporary storage
	var $editIcon;				// Temporary storage for page edit icon





	/**
	 * Initializing the module
	 *
	 * @return	void
	 */
	function init()	{
		global $BE_USER;

			// Setting module configuration / page select clause
		$this->MCONF = $GLOBALS['MCONF'];
		$this->perms_clause = $BE_USER->getPagePermsClause(1);
		$this->backPath = $GLOBALS['BACK_PATH'];

			// GPvars:
		$this->id = intval(t3lib_div::_GP('id'));
		$this->pointer = t3lib_div::_GP('pointer');
		$this->imagemode = t3lib_div::_GP('imagemode');

		$this->clear_cache = t3lib_div::_GP('clear_cache');
		$this->popView = t3lib_div::_GP('popView');
		$this->edit_record = t3lib_div::_GP('edit_record');
		$this->new_unique_uid = t3lib_div::_GP('new_unique_uid');
		$this->search_field = t3lib_div::_GP('search_field');
		$this->search_levels = t3lib_div::_GP('search_levels');
		$this->showLimit = t3lib_div::_GP('showLimit');
		$this->returnUrl = t3lib_div::_GP('returnUrl');

			// Load page info array:
		$this->pageinfo = t3lib_BEfunc::readPageAccess($this->id,$this->perms_clause);

			// Initialize menu
		$this->menuConfig();

			// Setting sys language from session var:
 		$this->current_sys_language=intval($this->MOD_SETTINGS['language']);

			// Include scripts: QuickEdit
		if ($this->MOD_SETTINGS['function']==0)	{
			$this->include_once[]=PATH_t3lib.'class.t3lib_tceforms.php';
			$this->include_once[]=PATH_t3lib.'class.t3lib_clipboard.php';
			$this->include_once[]=PATH_t3lib.'class.t3lib_loaddbgroup.php';
			$this->include_once[]=PATH_t3lib.'class.t3lib_transferdata.php';
		}

			// Include scripts: Clear-cache cmd.
		if ($this->clear_cache)	{
			$this->include_once[]=PATH_t3lib.'class.t3lib_tcemain.php';
		}

			// CSH / Descriptions:
		$this->descrTable = '_MOD_'.$this->MCONF['name'];
	}

	/**
	 * Initialize menu array
	 *
	 * @return	void
	 */
	function menuConfig()	{
		global $BE_USER,$LANG,$TYPO3_CONF_VARS;

			// MENU-ITEMS:
		$this->MOD_MENU = array(
			'tt_board' => array(
				0 => $LANG->getLL('m_tt_board_0'),
				'expand' => $LANG->getLL('m_tt_board_expand')
			),
			'tt_address' => array(
				0 => $LANG->getLL('m_tt_address_0'),
				1 => $LANG->getLL('m_tt_address_1'),
				2 => $LANG->getLL('m_tt_address_2')
			),
			'tt_links' => array(
				0 => $LANG->getLL('m_default'),
				1 => $LANG->getLL('m_tt_links_1'),
				2 => $LANG->getLL('m_tt_links_2')
			),
			'tt_calender' => array (
				0 => $LANG->getLL('m_default'),
				'date' => $LANG->getLL('m_tt_calender_date'),
				'date_ext' => $LANG->getLL('m_tt_calender_date_ext'),
				'todo' => $LANG->getLL('m_tt_calender_todo'),
				'todo_ext' => $LANG->getLL('m_tt_calender_todo_ext')
			),
			'tt_products' => array (
				0 => $LANG->getLL('m_default'),
				'ext' => $LANG->getLL('m_tt_products_ext')
			),
			'tt_content_showHidden' => '',
			'showPalettes' => '',
			'showDescriptions' => '',
			'disableRTE' => '',
			'function' => array(
				1 => $LANG->getLL('m_function_1'),
				0 => $LANG->getLL('m_function_0'),
				2 => $LANG->getLL('m_function_2'),
				3 => $LANG->getLL('pageInformation')
			),
			'language' => array(
				0 => $LANG->getLL('m_default')
			)
		);

			 // First, select all pages_language_overlay records on the current page. Each represents a possibility for a language on the page. Add these to language selector.
		$res = $this->exec_languageQuery($this->id);
		while($lrow = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($res))	{
			if ($GLOBALS['BE_USER']->checkLanguageAccess($lrow['uid']))	{
				$this->MOD_MENU['language'][$lrow['uid']]=($lrow['hidden']?'('.$lrow['title'].')':$lrow['title']);
			}
		}

			// Find if there are ANY languages at all (and if not, remove the language option from function menu).
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery('uid', 'sys_language', ($BE_USER->isAdmin()?'':'hidden=0'));
		if (!$GLOBALS['TYPO3_DB']->sql_num_rows($res))	{
			unset($this->MOD_MENU['function']['2']);
		}

			// page/be_user TSconfig settings and blinding of menu-items
		$this->modSharedTSconfig = t3lib_BEfunc::getModTSconfig($this->id, 'mod.SHARED');
		$this->modTSconfig = t3lib_BEfunc::getModTSconfig($this->id,'mod.'.$this->MCONF['name']);
		if ($this->modTSconfig['properties']['QEisDefault'])	ksort($this->MOD_MENU['function']);
		$this->MOD_MENU['function'] = t3lib_BEfunc::unsetMenuItems($this->modTSconfig['properties'],$this->MOD_MENU['function'],'menu.function');

			// Remove QuickEdit as option if page type is not...
		if (!t3lib_div::inList($TYPO3_CONF_VARS['FE']['content_doktypes'].',6',$this->pageinfo['doktype']))	{
			unset($this->MOD_MENU['function'][0]);
		}

			// Setting alternative default label:
		if (($this->modSharedTSconfig['properties']['defaultLanguageLabel'] || $this->modTSconfig['properties']['defaultLanguageLabel']) && isset($this->MOD_MENU['language'][0]))	{
			$this->MOD_MENU['language'][0] = $this->modTSconfig['properties']['defaultLanguageLabel'] ? $this->modSharedTSconfig['properties']['defaultLanguageLabel'] : $this->modSharedTSconfig['properties']['defaultLanguageLabel'];
		}

			// Clean up settings
		$this->MOD_SETTINGS = t3lib_BEfunc::getModuleData($this->MOD_MENU, t3lib_div::_GP('SET'), $this->MCONF['name']);

			// For all elements to be shown in draft workspaces:
		if ($GLOBALS['BE_USER']->workspace!=0)	{
			$this->MOD_SETTINGS['tt_content_showHidden'] = 1;
		}
	}

	/**
	 * Clears page cache for the current id, $this->id
	 *
	 * @return	void
	 */
	function clearCache()	{
		if ($this->clear_cache)	{
			$tce = t3lib_div::makeInstance('t3lib_TCEmain');
			$tce->stripslashes_values=0;
			$tce->start(Array(),Array());
			$tce->clear_cacheCmd($this->id);
		}
	}

	/**
	 * Main function.
	 * Creates some general objects and calls other functions for the main rendering of module content.
	 *
	 * @return	void
	 */
	function main()	{
		global $BE_USER,$LANG,$BACK_PATH;

		// Access check...
		// The page will show only if there is a valid page and if this page may be viewed by the user
		$access = is_array($this->pageinfo) ? 1 : 0;
		if ($this->id && $access)	{

				// Initialize permission settings:
			$this->CALC_PERMS = $BE_USER->calcPerms($this->pageinfo);
			$this->EDIT_CONTENT = ($this->CALC_PERMS&16) ? 1 : 0;

				// Start document template object:
			$this->doc = t3lib_div::makeInstance('mediumDoc');
			$this->doc->backPath = $BACK_PATH;
			$this->doc->docType='xhtml_trans';

				// JavaScript:
			$this->doc->JScode = '<script type="text/javascript" src="'.$BACK_PATH.'../t3lib/jsfunc.updateform.js"></script>';
			$this->doc->JScode.= $this->doc->wrapScriptTags('
				if (top.fsMod) top.fsMod.recentIds["web"] = '.intval($this->id).';
				if (top.fsMod) top.fsMod.navFrameHighlightedID["web"] = "pages'.intval($this->id).'_"+top.fsMod.currentBank; '.intval($this->id).';
				function jumpToUrl(URL,formEl)	{	//
					if (document.editform && document.TBE_EDITOR_isFormChanged)	{	// Check if the function exists... (works in all browsers?)
						if (!TBE_EDITOR_isFormChanged())	{	//
							window.location.href = URL;
						} else if (formEl) {
							if (formEl.type=="checkbox") formEl.checked = formEl.checked ? 0 : 1;
						}
					} else window.location.href = URL;
				}
			'.($this->popView ? t3lib_BEfunc::viewOnClick($this->id,$BACK_PATH,t3lib_BEfunc::BEgetRootLine($this->id)) : '').'

				function deleteRecord(table,id,url)	{	//
					if (confirm('.$LANG->JScharCode($LANG->getLL('deleteWarning')).'))	{
						window.location.href = "'.$BACK_PATH.'tce_db.php?cmd["+table+"]["+id+"][delete]=1&redirect="+escape(url)+"&vC='.$BE_USER->veriCode().'&prErr=1&uPT=1";
					}
					return false;
				}
			');

				// Setting doc-header
			$this->doc->form='<form action="'.htmlspecialchars('db_layout.php?id='.$this->id.'&imagemode='.$this->imagemode).'" method="post">';

				// Creating the top function menu:
			$this->topFuncMenu = t3lib_BEfunc::getFuncMenu($this->id,'SET[function]',$this->MOD_SETTINGS['function'],$this->MOD_MENU['function'],'db_layout.php','').
						(count($this->MOD_MENU['language'])>1 ? '<br />'.t3lib_BEfunc::getFuncMenu($this->id,'SET[language]',$this->current_sys_language,$this->MOD_MENU['language'],'db_layout.php','') : '');

				// Creating the top edit page icon:
			if ($this->CALC_PERMS&2)	{
				$params='&edit[pages]['.$this->id.']=edit';
				$this->editIcon='<a href="#" onclick="'.htmlspecialchars(t3lib_BEfunc::editOnClick($params,$BACK_PATH)).'"><img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/edit2.gif','width="11" height="12"').' vspace="2" align="top" title="'.$LANG->getLL('editPageProperties',1).'" alt="" /></a>';
			} else {
				$this->editIcon='';
			}

				// Find columns
			$modTSconfig_SHARED = t3lib_BEfunc::getModTSconfig($this->id,'mod.SHARED');		// SHARED page-TSconfig settings.
			$this->colPosList = strcmp(trim($this->modTSconfig['properties']['tt_content.']['colPos_list']),'') ? trim($this->modTSconfig['properties']['tt_content.']['colPos_list']) : $modTSconfig_SHARED['properties']['colPos_list'];
			$this->colPosList = strcmp($this->colPosList,'')?$this->colPosList:'1,0,2,3';
			$this->colPosList = implode(',',array_unique(t3lib_div::intExplode(',',$this->colPosList)));		// Removing duplicates, if any


				// Render the primary module content:
			if ($this->MOD_SETTINGS['function']==0)	{
				$this->renderQuickEdit();	// QuickEdit
			} else {
				$this->renderListContent();	// All other listings
			}


				// ShortCut
			if ($BE_USER->mayMakeShortcut())	{
				$this->content.=$this->doc->spacer(20).$this->doc->section('',$this->doc->makeShortcutIcon('id,edit_record,pointer,new_unique_uid,search_field,search_levels,showLimit',implode(',',array_keys($this->MOD_MENU)),$this->MCONF['name']));
			}

				// Ending page:
			$this->content.=$this->doc->spacer(10);
			$this->content.=$this->doc->endPage();
		} else {

				// If no access or id value, create empty document:
			$this->doc = t3lib_div::makeInstance('mediumDoc');
			$this->doc->docType='xhtml_trans';
			$this->doc->backPath = $BACK_PATH;
			$this->doc->JScode = $this->doc->wrapScriptTags('
				if (top.fsMod) top.fsMod.recentIds["web"] = '.intval($this->id).';
			');
			$this->content=$this->doc->startPage($LANG->getLL('title'));
			$this->content.=$this->doc->section($LANG->getLL('clickAPage_header'),$LANG->getLL('clickAPage_content'),0,1);

			$this->content.= t3lib_BEfunc::cshItem($this->descrTable,'',$BACK_PATH,'<br/><br/>');

			$this->content.=$this->doc->endPage();
		}
	}

	/**
	 * Rendering the quick-edit view.
	 *
	 * @return	void
	 */
	function renderQuickEdit()	{
		global $LANG,$BE_USER,$BACK_PATH;

			// Alternative form tag; Quick Edit submits its content to tce_db.php.
		$this->doc->form='<form action="'.htmlspecialchars($BACK_PATH.'tce_db.php?&prErr=1&uPT=1').'" method="post" enctype="'.$GLOBALS['TYPO3_CONF_VARS']['SYS']['form_enctype'].'" name="editform" onsubmit="return TBE_EDITOR_checkSubmit(1);">';

			// Setting up the context sensitive menu:
		$CMparts = $this->doc->getContextMenuCode();
		$this->doc->JScode.= $CMparts[0];
		$this->doc->bodyTagAdditions = $CMparts[1];
		$this->doc->postCode.= $CMparts[2];

			// Set the edit_record value for internal use in this function:
		$edit_record = $this->edit_record;

			// If a command to edit all records in a column is issue, then select all those elements, and redirect to alt_doc.php:
		if (substr($edit_record,0,9)=='_EDIT_COL')	{
			$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery(
						'*',
						'tt_content',
						'pid='.intval($this->id).' AND colPos='.intval(substr($edit_record,10)).' AND sys_language_uid='.intval($this->current_sys_language).
								($this->MOD_SETTINGS['tt_content_showHidden'] ? '' : t3lib_BEfunc::BEenableFields('tt_content')).
								t3lib_BEfunc::deleteClause('tt_content').
								t3lib_BEfunc::versioningPlaceholderClause('tt_content'),
						'',
						'sorting'
					);
			$idListA = array();
			while($cRow = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($res))	{
				$idListA[] = $cRow['uid'];
			}

			$url = $BACK_PATH.'alt_doc.php?edit[tt_content]['.implode(',',$idListA).']=edit&returnUrl='.rawurlencode($this->local_linkThisScript(array('edit_record'=>'')));
			header('Location: '.t3lib_div::locationHeaderUrl($url));
			exit;
		}

			// If the former record edited was the creation of a NEW record, this will look up the created records uid:
		if ($this->new_unique_uid)	{
			$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery('*', 'sys_log', 'userid='.intval($BE_USER->user['uid']).' AND NEWid='.$GLOBALS['TYPO3_DB']->fullQuoteStr($this->new_unique_uid, 'sys_log'));
			$sys_log_row = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($res);
			if (is_array($sys_log_row))	{
				$edit_record=$sys_log_row['tablename'].':'.$sys_log_row['recuid'];
			}
		}


			// Creating the selector box, allowing the user to select which element to edit:
		$opt=array();
		$is_selected=0;
		$languageOverlayRecord='';
		if ($this->current_sys_language)	{
			list($languageOverlayRecord) = t3lib_BEfunc::getRecordsByField('pages_language_overlay','pid',$this->id,'AND sys_language_uid='.intval($this->current_sys_language));
		}
		if (is_array($languageOverlayRecord))	{
			$inValue = 'pages_language_overlay:'.$languageOverlayRecord['uid'];
			$is_selected+=intval($edit_record==$inValue);
			$opt[]='<option value="'.$inValue.'"'.($edit_record==$inValue?' selected="selected"':'').'>[ '.$LANG->getLL('editLanguageHeader',1).' ]</option>';
		} else {
			$inValue = 'pages:'.$this->id;
			$is_selected+=intval($edit_record==$inValue);
			$opt[]='<option value="'.$inValue.'"'.($edit_record==$inValue?' selected="selected"':'').'>[ '.$LANG->getLL('editPageProperties',1).' ]</option>';
		}

			// Selecting all content elements from this language and allowed colPos:
		$res = $GLOBALS['TYPO3_DB']->exec_SELECTquery(
					'*',
					'tt_content',
					'pid='.intval($this->id).' AND sys_language_uid='.intval($this->current_sys_language).' AND colPos IN ('.$this->colPosList.')'.
							($this->MOD_SETTINGS['tt_content_showHidden'] ? '' : t3lib_BEfunc::BEenableFields('tt_content')).
							t3lib_Befunc::deleteClause('tt_content').
							t3lib_BEfunc::versioningPlaceholderClause('tt_content'),
					'',
					'colPos,sorting'
				);
		$colPos='';
		$first=1;
		$prev=$this->id;	// Page is the pid if no record to put this after.
		while($cRow = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($res))	{
			t3lib_BEfunc::workspaceOL('tt_content', $cRow);
			if ($first)	{
				if (!$edit_record)	{
					$edit_record='tt_content:'.$cRow['uid'];
				}
				$first = 0;
			}
			if (strcmp($cRow['colPos'],$colPos))	{
				$colPos=$cRow['colPos'];
				$opt[]='<option value=""></option>';
				$opt[]='<option value="_EDIT_COL:'.$colPos.'">__'.$LANG->sL(t3lib_BEfunc::getLabelFromItemlist('tt_content','colPos',$colPos),1).':__</option>';
			}
			$inValue = 'tt_content:'.$cRow['uid'];
			$is_selected+=intval($edit_record==$inValue);
			$opt[]='<option value="'.$inValue.'"'.($edit_record==$inValue?' selected="selected"':'').'>'.htmlspecialchars(t3lib_div::fixed_lgd_cs($cRow['header']?$cRow['header']:'['.$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.no_title').'] '.strip_tags($cRow['bodytext']),$BE_USER->uc['titleLen'])).'</option>';
			$prev=-$cRow['uid'];
		}

			// If edit_record is not set (meaning, no content elements was found for this language) we simply set it to create a new element:
		if (!$edit_record)	{
			$edit_record='tt_content:new/'.$prev.'/'.$colPos;

			$inValue = 'tt_content:new/'.$prev.'/'.$colPos;
			$is_selected+=intval($edit_record==$inValue);
			$opt[]='<option value="'.$inValue.'"'.($edit_record==$inValue?' selected="selected"':'').'>[ '.$LANG->getLL('newLabel',1).' ]</option>';
		}

			// If none is yet selected...
		if (!$is_selected)	{
			$opt[]='<option value=""></option>';
			$opt[]='<option value="'.$edit_record.'"  selected="selected">[ '.$LANG->getLL('newLabel',1).' ]</option>';
		}


			// Splitting the edit-record cmd value into table/uid:
		$eRParts = explode(':',$edit_record);



			// Delete-button flag?
		$deleteButton = (t3lib_div::testInt($eRParts[1]) && $edit_record && (($eRParts[0]!='pages'&&$this->EDIT_CONTENT) || ($eRParts[0]=='pages'&&($this->CALC_PERMS&4))));

			// If undo-button should be rendered (depends on available items in sys_history)
		$undoButton=0;
		$undoRes = $GLOBALS['TYPO3_DB']->exec_SELECTquery('tstamp', 'sys_history', 'tablename='.$GLOBALS['TYPO3_DB']->fullQuoteStr($eRParts[0], 'sys_history').' AND recuid='.intval($eRParts[1]), '', 'tstamp DESC', '1');
		if ($undoButtonR = $GLOBALS['TYPO3_DB']->sql_fetch_assoc($undoRes))	{
			$undoButton=1;
		}

			// Setting up the Return URL for coming back to THIS script (if links take the user to another script)
		$R_URL_parts = parse_url(t3lib_div::getIndpEnv('REQUEST_URI'));
		$R_URL_getvars = t3lib_div::_GET();

		unset($R_URL_getvars['popView']);
		unset($R_URL_getvars['new_unique_uid']);
		$R_URL_getvars['edit_record']=$edit_record;
		$R_URI = $R_URL_parts['path'].'?'.t3lib_div::implodeArrayForUrl('',$R_URL_getvars);

			// Setting close url/return url for exiting this script:
		$closeUrl = $this->local_linkThisScript(array('SET'=>array('function'=>1)));	// Goes to 'Columns' view if close is pressed (default)

		if ($BE_USER->uc['condensedMode'])	{
			$closeUrl = $BACK_PATH.'alt_db_navframe.php';
		}
		if ($this->returnUrl)	{
			$closeUrl = $this->returnUrl;
		}
			// Return-url for JavaScript:
		$retUrlStr = $this->returnUrl?"+'&returnUrl='+'".rawurlencode($this->returnUrl)."'":'';

			// Drawing tool bar:
		$toolBar=
			'<select name="edit_record" onchange="'.htmlspecialchars('jumpToUrl(\'db_layout.php?id='.$this->id.'&edit_record=\'+escape(this.options[this.selectedIndex].value)'.$retUrlStr.',this);').'">'.implode('',$opt).'</select>'.

			'<input class="c-inputButton" type="image" name="savedok"'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/savedok.gif','').' title="'.$LANG->sL('LLL:EXT:lang/locallang_core.php:rm.saveDoc',1).'" alt="" />'.

			'<a href="#" onclick="'.htmlspecialchars('document.editform.redirect.value+=\'&popView=1\'; TBE_EDITOR_checkAndDoSubmit(1); return false;').'">'.
				'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/savedokshow.gif','width="21" height="16"').' class="c-inputButton" title="'.$LANG->sL('LLL:EXT:lang/locallang_core.php:rm.saveDocShow',1).'" alt="" />'.
				'</a>'.

			'<a href="#" onclick="'.htmlspecialchars('jumpToUrl(unescape(\''.rawurlencode($closeUrl).'\')); return false;').'">'.
				'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/closedok.gif','width="21" height="16"').' class="c-inputButton" title="'.$LANG->sL('LLL:EXT:lang/locallang_core.php:rm.closeDoc',1).'" alt="" />'.
				'</a>'.

			($deleteButton ? '<a href="#" onclick="'.htmlspecialchars('return deleteRecord(\''.$eRParts[0].'\',\''.$eRParts[1].'\',\''.t3lib_div::getIndpEnv('SCRIPT_NAME').'?id='.$this->id.'\');').'">'.
							'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/deletedok.gif','width="21" height="16"').' class="c-inputButton" title="'.$LANG->getLL('deleteItem',1).'" alt="" />'.
							'</a>' : '').

			($undoButton ? '<a href="#" onclick="'.htmlspecialchars('window.location.href=\''.$BACK_PATH.'show_rechis.php?element='.rawurlencode($eRParts[0].':'.$eRParts[1]).'&revert=ALL_FIELDS&sumUp=-1&returnUrl='.rawurlencode($R_URI).'\'; return false;').'">'.
							'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/undo.gif','width="21" height="16"').' class="c-inputButton" title="'.htmlspecialchars(sprintf($LANG->getLL('undoLastChange'),t3lib_BEfunc::calcAge(time()-$undoButtonR['tstamp'],$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.minutesHoursDaysYears')))).'" alt="" />'.
							'</a>' : '');

		$toolBar.='<img src="clear.gif" width="15" height="1" align="top" alt="" />';

		$toolBar.=$undoButton?'<a href="#" onclick="'.htmlspecialchars('jumpToUrl(\''.$BACK_PATH.'show_rechis.php?element='.rawurlencode($eRParts[0].':'.$eRParts[1]).'&returnUrl='.rawurlencode($R_URI).'#latest\');return false;').'">'.
					'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/history2.gif','width="13" height="12"').' class="c-inputButton" title="'.$LANG->getLL('recordHistory',1).'" alt="" />'.
					'</a>':'';

		$toolBar.='<a href="'.htmlspecialchars('db_new_content_el.php?id='.$this->id.'&sys_language_uid='.$this->current_sys_language.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'">'.
					'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_record.gif','width="16" height="12"').' class="c-inputButton" title="'.$LANG->getLL('newContentElement',1).'" alt="" />'.
					'</a>';

		if (t3lib_div::testInt($eRParts[1])) $toolBar.='<a href="'.htmlspecialchars($BACK_PATH.'move_el.php?table='.$eRParts[0].'&uid='.$eRParts[1].'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'"><img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/move_'.($eRParts[0]=='tt_content'?'record':'page').'.gif','width="11" height="12"').' class="c-inputButton" title="'.$LANG->getLL('move_'.($eRParts[0]=='tt_content'?'record':'page'),1).'" alt="" /></a>';

		$toolBar.='<a href="#" onclick="'.htmlspecialchars('jumpToUrl(\''.$BACK_PATH.'db_new.php?id='.$this->id.'&pagesOnly=1&returnUrl='.rawurlencode($R_URI).'\');return false;').'">'.
				'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_page.gif','width="13" height="12"').' class="c-inputButton" title="'.$LANG->getLL('newPage',1).'" alt="" />'.
				'</a>';

		$toolBar.='<a href="'.htmlspecialchars($this->local_linkThisScript(array('edit_record'=>'pages:'.$this->id))).'">'.
				'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/edit2.gif','width="11" height="12"').' class="c-inputButton" title="'.$LANG->getLL('editPageProperties',1).'" alt="" />'.
				'</a>';
		$toolBar.='<img src="clear.gif" width="15" height="1" align="top" alt="" />';

			// CSH:
		$toolBar.= t3lib_BEfunc::cshItem($this->descrTable,'quickEdit',$BACK_PATH,'',FALSE,'margin-top: 0px; margin-bottom: 0px;');

			// Setting page properties:
		$hS2 = '
			<table border="0" cellpadding="0" cellspacing="0" width="460">
				<tr>
					<td valign="top" width="99%">'.$this->doc->getHeader('pages',$this->pageinfo,$this->pageinfo['_thePath'],0,explode('|','<a href="'.htmlspecialchars($this->local_linkThisScript(array('edit_record'=>'pages:'.$this->id))).'">|</a>')).'</td>
					<td valign="top" width="1%">'.$this->topFuncMenu.'</td>
					<td valign="top" width="1%"><img src="clear.gif" width="1" height="3" alt="" /><br />'.$this->editIcon.'</td>
				</tr>
				<tr>
					<td><img src="clear.gif" width="300" height="1" alt="" /></td>
					<td></td>
					<td></td>
				</tr>
				<tr>
					<td colspan="3" class="bgColor4">'.$toolBar.'</td>
				</tr>
			</table>';

		$content.=$this->doc->startPage($LANG->getLL('title'));
		$content.=$this->doc->section('',$hS2);
		$content.=$this->doc->spacer(7);

			// Creating editing form:
		if ($BE_USER->check('tables_modify',$eRParts[0]) && $edit_record && (($eRParts[0]!='pages'&&$this->EDIT_CONTENT) || ($eRParts[0]=='pages'&&($this->CALC_PERMS&1))))	{

				// Splitting uid parts for special features, if new:
			list($uidVal,$ex_pid,$ex_colPos) = explode('/',$eRParts[1]);

				// Convert $uidVal to workspace version if any:
			if ($uidVal!='new')	{
				if ($draftRecord = t3lib_BEfunc::getWorkspaceVersionOfRecord($GLOBALS['BE_USER']->workspace, $eRParts[0], $uidVal, 'uid'))	{
					$uidVal = $draftRecord['uid'];
				}
			}

				// Initializing transfer-data object:
			$trData = t3lib_div::makeInstance('t3lib_transferData');
			$trData->addRawData = TRUE;
			$trData->defVals[$eRParts[0]] = array (
				'colPos' => intval($ex_colPos),
				'sys_language_uid' => intval($this->current_sys_language)
			);
			$trData->disableRTE = $this->MOD_SETTINGS['disableRTE'];
			$trData->lockRecords=1;
			$trData->fetchRecord($eRParts[0],($uidVal=='new'?$this->id:$uidVal),$uidVal);	// 'new'

				// Getting/Making the record:
			reset($trData->regTableItems_data);
			$rec = current($trData->regTableItems_data);
			if ($uidVal=='new')	{
				$new_unique_uid = uniqid('NEW');
				$rec['uid'] = $new_unique_uid;
				$rec['pid'] = intval($ex_pid)?intval($ex_pid):$this->id;
				$recordAccess = TRUE;
			} else {
				$rec['uid'] = $uidVal;

					// Checking internals access:
				$recordAccess = $BE_USER->recordEditAccessInternals($eRParts[0],$uidVal);
			}

			if (!$recordAccess)	{
					// If no edit access, print error message:
				$content.=$this->doc->section($LANG->getLL('noAccess'),$LANG->getLL('noAccess_msg').'<br /><br />'.
							($BE_USER->errorMsg ? 'Reason: '.$BE_USER->errorMsg.'<br/><br/>' : ''),0,1);
			} elseif (is_array($rec))	{	// If the record is an array (which it will always be... :-)

					// Create instance of TCEforms, setting defaults:
				$tceforms = t3lib_div::makeInstance('t3lib_TCEforms');
				$tceforms->backPath = $BACK_PATH;
				$tceforms->initDefaultBEMode();
				$tceforms->fieldOrder = $this->modTSconfig['properties']['tt_content.']['fieldOrder'];
				$tceforms->palettesCollapsed = !$this->MOD_SETTINGS['showPalettes'];
				$tceforms->disableRTE = $this->MOD_SETTINGS['disableRTE'];
				$tceforms->enableClickMenu = TRUE;

					// Clipboard is initialized:
				$tceforms->clipObj = t3lib_div::makeInstance('t3lib_clipboard');		// Start clipboard
				$tceforms->clipObj->initializeClipboard();	// Initialize - reads the clipboard content from the user session


				if ($BE_USER->uc['edit_showFieldHelp']!='text' && $this->MOD_SETTINGS['showDescriptions'])	$tceforms->edit_showFieldHelp='text';

					// Render form, wrap it:
				$panel='';
				$panel.=$tceforms->getMainFields($eRParts[0],$rec);
				$panel=$tceforms->wrapTotal($panel,$rec,$eRParts[0]);

					// Add hidden fields:
				$theCode=$panel;
				if ($uidVal=='new')	{
					$theCode.='<input type="hidden" name="data['.$eRParts[0].']['.$rec['uid'].'][pid]" value="'.$rec['pid'].'" />';
				}
				$theCode.='
					<input type="hidden" name="_serialNumber" value="'.md5(microtime()).'" />
					<input type="hidden" name="_disableRTE" value="'.$tceforms->disableRTE.'" />
					<input type="hidden" name="edit_record" value="'.$edit_record.'" />
					<input type="hidden" name="redirect" value="'.htmlspecialchars($uidVal=='new' ? t3lib_extMgm::extRelPath('cms').'layout/db_layout.php?id='.$this->id.'&new_unique_uid='.$new_unique_uid.'&returnUrl='.rawurlencode($this->returnUrl) : $R_URI ).'" />
					';

					// Add JavaScript as needed around the form:
				$theCode=$tceforms->printNeededJSFunctions_top().$theCode.$tceforms->printNeededJSFunctions();

					// Add warning sign if record was "locked":
				if ($lockInfo=t3lib_BEfunc::isRecordLocked($eRParts[0],$rec['uid']))	{
					$lockIcon='

						<!--
						 	Warning box:
						-->
						<table border="0" cellpadding="0" cellspacing="0" class="warningbox">
							<tr>
								<td><img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/recordlock_warning3.gif','width="17" height="12"').' alt="" /></td>
								<td>'.htmlspecialchars($lockInfo['msg']).'</td>
							</tr>
						</table>
						';
				} else $lockIcon='';

					// Add whole form as a document section:
				$content.=$this->doc->section('',$lockIcon.$theCode);
			}
		} else {
				// If no edit access, print error message:
			$content.=$this->doc->section($LANG->getLL('noAccess'),$LANG->getLL('noAccess_msg').'<br /><br />',0,1);
		}


			// Bottom controls (function menus):
		$q_count = $this->getNumberOfHiddenElements();
		$h_func_b= t3lib_BEfunc::getFuncCheck($this->id,'SET[tt_content_showHidden]',$this->MOD_SETTINGS['tt_content_showHidden'],'db_layout.php','').
					(!$q_count?$GLOBALS['TBE_TEMPLATE']->dfw($LANG->getLL('hiddenCE',1)):$LANG->getLL('hiddenCE',1).' ('.$q_count.')');

		$h_func_b.= '<br />'.
					t3lib_BEfunc::getFuncCheck($this->id,'SET[showPalettes]',$this->MOD_SETTINGS['showPalettes'],'db_layout.php','').
					$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.showPalettes',1);

		if (t3lib_extMgm::isLoaded('context_help') && $BE_USER->uc['edit_showFieldHelp']!='text') {
			$h_func_b.= '<br />'.
						t3lib_BEfunc::getFuncCheck($this->id,'SET[showDescriptions]',$this->MOD_SETTINGS['showDescriptions'],'db_layout.php','').
						$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.showDescriptions',1);
		}

		if ($BE_USER->isRTE())	{
			$h_func_b.= '<br />'.
						t3lib_BEfunc::getFuncCheck($this->id,'SET[disableRTE]',$this->MOD_SETTINGS['disableRTE'],'db_layout.php','').
						$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.disableRTE',1);
		}

			// Add the function menus to bottom:
		$content.=$this->doc->section('',$h_func_b,0,0);
		$content.=$this->doc->spacer(10);


			// Select element matrix:
		if ($eRParts[0]=='tt_content' && t3lib_div::testInt($eRParts[1]))	{
			$posMap = t3lib_div::makeInstance('ext_posMap');
			$posMap->backPath = $BACK_PATH;
			$posMap->cur_sys_language=$this->current_sys_language;

			$HTMLcode = '';

				// CSH:
			$HTMLcode.= t3lib_BEfunc::cshItem($this->descrTable,'quickEdit_selElement',$BACK_PATH,'|<br/>');

			$HTMLcode.=$posMap->printContentElementColumns($this->id,$eRParts[1],$this->colPosList,$this->MOD_SETTINGS['tt_content_showHidden'],$R_URI);

			$HTMLcode.='<br /><br />'.
						'<a href="'.htmlspecialchars($BACK_PATH.'move_el.php?table=tt_content&uid='.$eRParts[1].'&sys_language_uid='.$this->current_sys_language.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'"><img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/move_record.gif','width="11" height="12"').' vspace="0" hspace="5" align="top" title="'.$LANG->getLL('move_record',1).'" alt="" />'.
						$LANG->getLL('move_record',1).
						'</a>';

			$HTMLcode.='<br /><img src="clear.gif" width="1" height="5" alt="" />';
			$HTMLcode.='<br />'.
						'<a href="'.htmlspecialchars('db_new_content_el.php?id='.$this->id.'&sys_language_uid='.$this->current_sys_language.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_record.gif','width="16" height="12"').' vspace="0" hspace="2" align="top" title="'.$LANG->getLL('newContentElement',1).'" alt="" />'.
						$LANG->getLL('newContentElement',1).
						'</a>';

			$content.=$this->doc->spacer(20);
			$content.=$this->doc->section($LANG->getLL('CEonThisPage'),$HTMLcode,0,1);
			$content.=$this->doc->spacer(20);
		}

			// Finally, if comments were generated in TCEforms object, print these as a HTML comment:
		if (count($tceforms->commentMessages))	{
			$content.='
	<!-- TCEFORM messages
	'.htmlspecialchars(implode(chr(10),$tceforms->commentMessages)).'
	-->
	';
		}

			// Adding content to internal accumulation variable:
		$this->content.=$content;
	}

	/**
	 * Rendering all other listings than QuickEdit
	 *
	 * @return	void
	 */
	function renderListContent()	{
		global $LANG,$BACK_PATH,$TCA;

			// Initialize list object (see "class.db_layout.inc"):
		$dblist = t3lib_div::makeInstance('tx_cms_layout');
		$dblist->backPath = $BACK_PATH;
		$dblist->thumbs = $this->imagemode;
		$dblist->no_noWrap = 1;
		$dblist->descrTable = $this->descrTable;

		$this->pointer = t3lib_div::intInRange($this->pointer,0,100000);
		$dblist->script = 'db_layout.php';
		$dblist->showIcon = 0;
		$dblist->setLMargin=0;
		$dblist->doEdit = $this->EDIT_CONTENT;
		$dblist->ext_CALC_PERMS = $this->CALC_PERMS;

		$dblist->agePrefixes = $LANG->sL('LLL:EXT:lang/locallang_core.php:labels.minutesHoursDaysYears');
		$dblist->id = $this->id;
		$dblist->nextThree = t3lib_div::intInRange($this->modTSconfig['properties']['editFieldsAtATime'],0,10);
		$dblist->option_showBigButtons = $this->modTSconfig['properties']['disableBigButtons'] ? 0 : 1;
		$dblist->option_newWizard = $this->modTSconfig['properties']['disableNewContentElementWizard'] ? 0 : 1;
		$dblist->defLangBinding = $this->modTSconfig['properties']['defLangBinding'] ? 1 : 0;
		if (!$dblist->nextThree)	$dblist->nextThree = 1;

		$dblist->externalTables = $GLOBALS['TYPO3_CONF_VARS']['EXTCONF']['cms']['db_layout']['addTables'];


			// Create menu for selecting a table to jump to (this is, if more than just pages/tt_content elements are found on the page!)
		$h_menu = $dblist->getTableMenu($this->id);

			// Initialize other variables:
		$h_func='';
		$tableOutput=array();
		$tableJSOutput=array();
		$CMcounter = 0;

			// Traverse the list of table names which has records on this page (that array is populated by the $dblist object during the function getTableMenu()):
		reset($dblist->activeTables);
		while(list($table)=each($dblist->activeTables))	{

				// Load full table definitions:
			t3lib_div::loadTCA($table);

			if (!isset($dblist->externalTables[$table]))	{
					// Creating special conditions for each table:
				switch($table)	{
					case 'tt_board':
						$h_func = t3lib_BEfunc::getFuncMenu($this->id,'SET[tt_board]',$this->MOD_SETTINGS['tt_board'],$this->MOD_MENU['tt_board'],'db_layout.php','');
					break;
					case 'tt_address':
						$h_func = t3lib_BEfunc::getFuncMenu($this->id,'SET[tt_address]',$this->MOD_SETTINGS['tt_address'],$this->MOD_MENU['tt_address'],'db_layout.php','');
					break;
					case 'tt_links':
						$h_func = t3lib_BEfunc::getFuncMenu($this->id,'SET[tt_links]',$this->MOD_SETTINGS['tt_links'],$this->MOD_MENU['tt_links'],'db_layout.php','');
					break;
					case 'tt_calender':
						$h_func = t3lib_BEfunc::getFuncMenu($this->id,'SET[tt_calender]',$this->MOD_SETTINGS['tt_calender'],$this->MOD_MENU['tt_calender'],'db_layout.php','');
					break;
					case 'tt_products':
						$h_func = t3lib_BEfunc::getFuncMenu($this->id,'SET[tt_products]',$this->MOD_SETTINGS['tt_products'],$this->MOD_MENU['tt_products'],'db_layout.php','');
					break;
					case 'tt_guest':
					case 'tt_news':
					case 'fe_users':
						// Nothing
					break;
					case 'tt_content':
						$q_count = $this->getNumberOfHiddenElements();
						$h_func_b= t3lib_BEfunc::getFuncCheck($this->id,'SET[tt_content_showHidden]',$this->MOD_SETTINGS['tt_content_showHidden'],'db_layout.php','').(!$q_count?$GLOBALS['TBE_TEMPLATE']->dfw($LANG->getLL('hiddenCE')):$LANG->getLL('hiddenCE').' ('.$q_count.')');

						$dblist->tt_contentConfig['showCommands'] = 1;	// Boolean: Display up/down arrows and edit icons for tt_content records
						$dblist->tt_contentConfig['showInfo'] = 1;		// Boolean: Display info-marks or not
						$dblist->tt_contentConfig['single'] = 0; 		// Boolean: If set, the content of column(s) $this->tt_contentConfig['showSingleCol'] is shown in the total width of the page

							// Setting up the tt_content columns to show:
						if (is_array($TCA['tt_content']['columns']['colPos']['config']['items']))	{
							$colList = array();
							foreach($TCA['tt_content']['columns']['colPos']['config']['items'] as $temp)	{
								$colList[] = $temp[1];
							}
						} else {	// ... should be impossible that colPos has no array. But this is the fallback should it make any sense:
							$colList = array('1','0','2','3');
						}
						if (strcmp($this->colPosList,''))	{
							$colList = array_intersect(t3lib_div::intExplode(',',$this->colPosList),$colList);
						}

							// If only one column found, display the single-column view.
						if (count($colList)==1)	{
							$dblist->tt_contentConfig['single'] = 1;	// Boolean: If set, the content of column(s) $this->tt_contentConfig['showSingleCol'] is shown in the total width of the page
							$dblist->tt_contentConfig['showSingleCol'] = current($colList);	// The column(s) to show if single mode (under each other)
						}
						$dblist->tt_contentConfig['cols'] = implode(',',$colList);		// The order of the rows: Default is left(1), Normal(0), right(2), margin(3)
						$dblist->tt_contentConfig['showHidden'] = $this->MOD_SETTINGS['tt_content_showHidden'];
						$dblist->tt_contentConfig['sys_language_uid'] = intval($this->current_sys_language);

							// If the function menu is set to "Language":
						if ($this->MOD_SETTINGS['function']==2)	{
							$dblist->tt_contentConfig['single'] = 0;
							$dblist->tt_contentConfig['languageMode'] = 1;
							$dblist->tt_contentConfig['languageCols'] = $this->MOD_MENU['language'];
							$dblist->tt_contentConfig['languageColsPointer'] = $this->current_sys_language;
						}
					break;
				}
			} else {
				$h_func = '';
			}

				// Start the dblist object:
			$dblist->itemsLimitSingleTable = 1000;
			$dblist->start($this->id,$table,$this->pointer,$this->search_field,$this->search_levels,$this->showLimit);
			$dblist->counter = $CMcounter;
			$dblist->ext_function = $this->MOD_SETTINGS['function'];

				// Render versioning selector:
			$dblist->HTMLcode.= $this->doc->getVersionSelector($this->id);

				// Generate the list of elements here:
			$dblist->generateList();

				// Adding the list content to the tableOutput variable:
			$tableOutput[$table]=
							($h_func?$h_func.'<br /><img src="clear.gif" width="1" height="4" alt="" /><br />':'').
							$dblist->HTMLcode.
							($h_func_b?'<img src="clear.gif" width="1" height="10" alt="" /><br />'.$h_func_b:'');

				// ... and any accumulated JavaScript goes the same way!
			$tableJSOutput[$table] = $dblist->JScode;

				// Increase global counter:
			$CMcounter+= $dblist->counter;

				// Reset variables after operation:
			$dblist->HTMLcode='';
			$dblist->JScode='';
			$h_func = '';
			$h_func_b = '';
		}	// END: traverse tables


			// For Context Sensitive Menus:
		$CMparts = $this->doc->getContextMenuCode();
		$this->doc->bodyTagAdditions = $CMparts[1];
		$this->doc->JScode.= $CMparts[0];
		$this->doc->postCode.= $CMparts[2];


			// Draw the page properties.
		$headerSection = $this->doc->getHeader('pages',$this->pageinfo,$this->pageinfo['_thePath'],$this->modTSconfig['properties']['disableIconToolbar']?1:0).'<br />'.
						$LANG->sL('LLL:EXT:lang/locallang_core.php:labels.path',1).': '.
						'<span title="'.htmlspecialchars($this->pageinfo['_thePathFull']).'">'.htmlspecialchars(t3lib_div::fixed_lgd_cs($this->pageinfo['_thePath'],-50)).'</span>';

		if (!$this->modTSconfig['properties']['disableIconToolbar'])	{
				// Create icon "toolbar" for common operations like creating/moving elements/pages etc.
			$toolBar='';
				// History:
			$toolBar.='<a href="#" onclick="'.htmlspecialchars('jumpToUrl(\''.$BACK_PATH.'show_rechis.php?element='.rawurlencode('pages:'.$this->id).'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI')).'#latest\');return false;').'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/history2.gif','width="13" height="12"').' vspace="2" hspace="2" align="top" title="'.$LANG->getLL('recordHistory',1).'" alt="" />'.
						'</a>';
				// New content element
			$toolBar.='<a href="'.htmlspecialchars('db_new_content_el.php?id='.$this->id.'&sys_language_uid='.$this->current_sys_language.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_record.gif','width="16" height="12"').' vspace="2" hspace="1" align="top" title="'.$LANG->getLL('newContentElement',1).'" alt="" />'.
						'</a>';
				// Move page:
			$toolBar.='<a href="'.htmlspecialchars($BACK_PATH.'move_el.php?table=pages&uid='.$this->id.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/move_page.gif','width="11" height="12"').' vspace="2" hspace="2" align="top" title="'.$LANG->getLL('move_page',1).'" alt="" />'.
						'</a>';
				// Create new page (wizard):
			$toolBar.='<a href="#" onclick="'.htmlspecialchars('jumpToUrl(\''.$BACK_PATH.'db_new.php?id='.$this->id.'&pagesOnly=1&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI')).'\');return false;').'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_page.gif','width="13" height="12"').' hspace="0" vspace="2" align="top" title="'.$LANG->getLL('newPage',1).'" alt="" />'.
						'</a>';
				// Edit page properties:
			$params='&edit[pages]['.$this->id.']=edit';
			$toolBar.='<a href="#" onclick="'.htmlspecialchars(t3lib_BEfunc::editOnClick($params,$BACK_PATH)).'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/edit2.gif','width="11" height="12"').' hspace="2" vspace="2" align="top" title="'.$LANG->getLL('editPageProperties',1).'" alt="" />'.
						'</a>';

				// Add CSH (Context Sensitive Help) icon to tool bar:
			$toolBar.= t3lib_BEfunc::cshItem($this->descrTable,'columns_'.$this->MOD_SETTINGS['function'],$BACK_PATH,'',FALSE,'margin-top: 0px; margin-bottom: 0px;');

				// Wrap the toolbar into a table:
			$headerSection.='
				<table border="0" cellpadding="0" cellspacing="0" class="bgColor4">
					<tr>
						<td>'.$toolBar.'</td>
					</tr>
				</table>';
		}

			// Create menu of table-icons for jumping to table-listing anchor points:
		if ($this->MOD_SETTINGS['function']!=3 && count($tableOutput)>1)	{
			$goToTable_menu = '<td valign="top" width="1%" nowrap="nowrap">'.$h_menu.'</td>';
		} else {
			$goToTable_menu = '';
		}

			// Compile the whole header section into a table: Toolbar, Table selector, Function menu(s), Page-edit icon:
		$hS2='
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td valign="top" width="99%">'.$headerSection.'</td>
					'.$goToTable_menu.'
					<td valign="top" width="1%">'.$this->topFuncMenu.'</td>
					<td valign="top" align="right" width="1%"><img src="clear.gif" width="1" height="3" alt="" /><br />'.$this->editIcon.'</td>
				</tr>
			</table>';

			// Create page properties:
		$this->content.=$this->doc->startPage($LANG->getLL('title'));
		$this->content.=$this->doc->section('',$hS2);


			// Now, create listing based on which element is selected in the function menu:

		if ($this->MOD_SETTINGS['function']==3) {

				// Making page info:
			$this->content.=$this->doc->spacer(10);
			$this->content.=$this->doc->section($LANG->getLL('pageInformation'),$dblist->getPageInfoBox($this->pageinfo,$this->CALC_PERMS&2),0,1);
		} else {

				// Add the content for each table we have rendered (traversing $tableOutput variable)
			foreach($tableOutput as $table => $output)	{
				$this->content.=$this->doc->section('<a name="'.$table.'"></a>'.$dblist->activeTables[$table],$output,TRUE,TRUE,0,TRUE);
				$this->content.=$this->doc->spacer(15);
				$this->content.=$this->doc->sectionEnd();
			}

				// Making search form:
			if (!$this->modTSconfig['properties']['disableSearchBox'] && count($tableOutput))	{
				$this->content.=$this->doc->section($LANG->sL('LLL:EXT:lang/locallang_core.php:labels.search'),$dblist->getSearchBox(),0,1);
			}

				// Making display of Sys-notes (from extension "sys_note")
			$dblist->id=$this->id;
			$sysNotes = $dblist->showSysNotesForPage();
			if ($sysNotes)	{
				$this->content.=$this->doc->spacer(10);
				$this->content.=$this->doc->section($LANG->getLL('internalNotes'),$sysNotes,0,1);
			}

				// Display advanced options: Clear cache, new record link etc:
			if (!$this->modTSconfig['properties']['disableAdvanced'])	{

					// Clear cache links:
				$af_content = $this->doc->clearCacheMenu($this->id);

					// "Create new record" link:
				if (!$this->modTSconfig['properties']['noCreateRecordsLink']) {
					$af_content.='

					<!--
						Link for creating a new record:
					-->
					<div id="typo3-newRecordLink">
							<a href="'.htmlspecialchars($BACK_PATH.'db_new.php?id='.$this->id.'&returnUrl='.rawurlencode(t3lib_div::getIndpEnv('REQUEST_URI'))).'">'.
						'<img'.t3lib_iconWorks::skinImg($BACK_PATH,'gfx/new_el.gif','width="11" height="12"').' alt="" />'.
						$LANG->getLL('newRecordGeneral',1).
						'</a>
					</div>';
				}

					// Add content of the advanced-options section:
				$this->content.=$this->doc->spacer(10);
				$this->content.=$this->doc->section($LANG->getLL('advancedFunctions'),$af_content,0,1);
			}

				// Add spacer in bottom of page:
			$this->content.=$this->doc->spacer(10);
		}
	}

	/**
	 * Print accumulated content of module
	 *
	 * @return	void
	 */
	function printContent()	{
		echo $this->content;
	}













	/*******************************
	 *
	 * Other functions
	 *
	 ******************************/

	/**
	 * Returns the number of hidden elements (including those hidden by start/end times) on the current page (for the current sys_language)
	 *
	 * @return	void
	 */
	function getNumberOfHiddenElements()	{
		$q_res = $GLOBALS['TYPO3_DB']->exec_SELECTquery('count(*)', 'tt_content', 'pid='.intval($this->id).' AND sys_language_uid='.intval($this->current_sys_language).t3lib_BEfunc::BEenableFields('tt_content',1).t3lib_BEfunc::deleteClause('tt_content').t3lib_BEfunc::versioningPlaceholderClause('tt_content'));
		list($q_count) = $GLOBALS['TYPO3_DB']->sql_fetch_row($q_res);
		return $q_count;
	}

	/**
	 * Returns URL to the current script.
	 * In particular the "popView" and "new_unique_uid" Get vars are unset.
	 *
	 * @param	array		Parameters array, merged with global GET vars.
	 * @return	string		URL
	 */
	function local_linkThisScript($params)	{
		$params['popView']='';
		$params['new_unique_uid']='';
		return t3lib_div::linkThisScript($params);
	}

	/**
	 * Returns a SQL query for selecting sys_language records.
	 *
	 * @param	integer		Page id: If zero, the query will select all sys_language records from root level which are NOT hidden. If set to another value, the query will select all sys_language records that has a pages_language_overlay record on that page (and is not hidden, unless you are admin user)
	 * @return	string		Return query string.
	 */
	function exec_languageQuery($id)	{
		$exQ = $GLOBALS['BE_USER']->isAdmin() ? '' : ' AND sys_language.hidden=0';
		if ($id)	{
			return $GLOBALS['TYPO3_DB']->exec_SELECTquery(
							'sys_language.*',
							'pages_language_overlay,sys_language',
							'pages_language_overlay.sys_language_uid=sys_language.uid AND pages_language_overlay.pid='.intval($id).$exQ,
							'pages_language_overlay.sys_language_uid,sys_language.uid,sys_language.pid,sys_language.tstamp,sys_language.hidden,sys_language.title,sys_language.static_lang_isocode,sys_language.flag',
							'sys_language.title'
						);
		} else {
			return $GLOBALS['TYPO3_DB']->exec_SELECTquery(
							'sys_language.*',
							'sys_language',
							'sys_language.hidden=0',
							'',
							'sys_language.title'
						);
		}
	}
}

// Include extension?
if (defined('TYPO3_MODE') && $TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/cms/layout/db_layout.php'])	{
	include_once($TYPO3_CONF_VARS[TYPO3_MODE]['XCLASS']['ext/cms/layout/db_layout.php']);
}












// Make instance:
$SOBE = t3lib_div::makeInstance('SC_db_layout');
$SOBE->init();

// Include files?
foreach($SOBE->include_once as $INC_FILE)	include_once($INC_FILE);

$SOBE->clearCache();
$SOBE->main();
$SOBE->printContent();
?>
