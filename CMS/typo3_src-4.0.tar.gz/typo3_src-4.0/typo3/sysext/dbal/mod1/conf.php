<?php

	// DO NOT REMOVE OR CHANGE THESE 3 LINES:
define('TYPO3_MOD_PATH', 'sysext/dbal/mod1/');
$BACK_PATH='../../../';
$MCONF['name']='tools_txdbalM1';

	
$MCONF['access']='admin';
$MCONF['script']='index.php';

$MLANG['default']['tabs_images']['tab'] = 'moduleicon.gif';
$MLANG['default']['ll_ref']='LLL:EXT:dbal/mod1/locallang_mod.xml';
?>