<?php
define('TYPO3_MOD_PATH', 'sysext/belog/mod/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'log.gif';
$MLANG['default']['ll_ref']='LLL:EXT:belog/mod/locallang_mod.php';

$MCONF['script']='index.php';
$MCONF['access']='admin';
$MCONF['name']='tools_log';
?>