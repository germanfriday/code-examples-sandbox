<?php
define('TYPO3_MOD_PATH', 'sysext/beuser/mod/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'beuser.gif';
$MLANG['default']['ll_ref']='LLL:EXT:beuser/mod/locallang_mod.php';

$MCONF['script']='index.php';
$MCONF['access']='admin';
$MCONF['name']='tools_beuser';
$MCONF['workspaces']='online';

?>