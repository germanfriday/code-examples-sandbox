<?php
define('TYPO3_MOD_PATH', 'sysext/aboutmodules/mod/');
$BACK_PATH='';

$MLANG['default']['tabs_images']['tab'] = 'aboutmodules.gif';
$MLANG['default']['ll_ref']='LLL:EXT:aboutmodules/mod/locallang_mod.xml';

$MCONF['script'] = '../../../alt_intro.php';
$MCONF['name'] = 'help_aboutmodules';
?>