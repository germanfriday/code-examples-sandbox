TYPO3 Backend Administration

This directory contains the core TYPO3 backend interface.
This is an out-of-the-box interface for editing the database content and managing the files which are under the control of TYPO3.
The interface provides a solid framework for CMS and has an API for extension via custom made modules.

You should read the document titled "Inside TYPO3" for a description of the TYPO3 core, this interface and how to use it, extend it etc.
