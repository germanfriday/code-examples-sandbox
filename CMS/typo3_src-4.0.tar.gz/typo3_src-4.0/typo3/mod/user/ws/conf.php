<?php
define('TYPO3_MOD_PATH', 'mod/user/ws/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'sys_workspace.png';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_user_ws.php';

$MCONF['shy'] = FALSE;
$MCONF['script'] = 'index.php';
$MCONF['access']='user,group';
$MCONF['name']='user_ws';
?>