<?php
$MLANG['default']['tabs_images']['tab'] = 'help.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_help.php';

$MCONF['defaultMod']='welcome';
$MCONF['name']='help';
?>