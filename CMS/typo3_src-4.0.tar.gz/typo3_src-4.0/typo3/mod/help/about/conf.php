<?php
define('TYPO3_MOD_PATH', 'mod/help/about/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'info.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_help_about.php';

$MCONF['script']='index.php';
$MCONF['name']='help_about';
?>