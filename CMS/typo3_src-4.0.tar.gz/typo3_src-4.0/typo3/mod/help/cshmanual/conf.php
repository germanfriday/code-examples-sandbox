<?php
define('TYPO3_MOD_PATH', 'mod/help/cshmanual/');
$BACK_PATH = '../../../';

$MLANG['default']['tabs_images']['tab'] = 'ext_icon.gif';
$MLANG['default']['ll_ref'] = 'LLL:EXT:lang/locallang_mod_help_cshmanual.php';

$MCONF['script'] = $BACK_PATH.'view_help.php';
$MCONF['name'] = 'help_cshmanual';
?>