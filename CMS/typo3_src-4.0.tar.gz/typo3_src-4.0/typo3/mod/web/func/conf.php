<?php
define('TYPO3_MOD_PATH', 'mod/web/func/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'func.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_web_func.php';

$MCONF['script']='index.php';
$MCONF['access']='user,group';
$MCONF['name']='web_func';
?>