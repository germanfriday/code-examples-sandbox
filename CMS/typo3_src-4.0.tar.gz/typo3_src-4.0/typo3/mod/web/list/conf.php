<?php
define('TYPO3_MOD_PATH', 'mod/web/list/');
$BACK_PATH='';

$MLANG['default']['tabs_images']['tab'] = 'list.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_web_list.php';

$MCONF['script']='../../../db_list.php';
$MCONF['access']='user,group';
$MCONF['name']='web_list';

?>