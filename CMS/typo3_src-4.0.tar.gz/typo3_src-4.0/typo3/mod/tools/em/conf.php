<?php
define('TYPO3_MOD_PATH', 'mod/tools/em/');
$BACK_PATH='../../../';

$MLANG['default']['tabs_images']['tab'] = 'em.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_tools_em.php';

$MCONF['script']='index.php';
$MCONF['access']='admin';
$MCONF['name']='tools_em';
$MCONF['workspaces']='online';
?>