<?php
$MLANG['default']['tabs_images']['tab'] = 'tool.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_tools.php';

$MCONF['name']='tools';
$MCONF['access']='admin';
#$MCONF['workspaces']='online';
?>