<?php
$MLANG['default']['tabs_images']['tab'] = 'document.gif';
$MLANG['default']['ll_ref']='LLL:EXT:lang/locallang_mod_doc.php';

$MCONF['script']='../../alt_doc.php';
$MCONF['access']='group,user';
?>