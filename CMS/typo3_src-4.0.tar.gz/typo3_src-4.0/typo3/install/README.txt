typo3/install/

Trigger script for the install tool.
You can access the install tool from ".../typo3/install/"
Notice: The "install" extension has to be loaded.