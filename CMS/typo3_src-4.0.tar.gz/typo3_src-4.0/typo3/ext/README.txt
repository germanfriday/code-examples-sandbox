This is only a placeholder. You can use this directory for storing global extensions.
